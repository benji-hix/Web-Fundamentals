console.log("page loaded...");

// I was able to get this to function with purely html, 
// was javascript even needed?
